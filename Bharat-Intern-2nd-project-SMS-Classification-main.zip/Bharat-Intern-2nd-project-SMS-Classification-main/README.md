# Bharat-Intern-2nd-project-SMS-Classification
Developed a text classification model to classify SMS as either spam or non-spam using data science techniques in Python.
